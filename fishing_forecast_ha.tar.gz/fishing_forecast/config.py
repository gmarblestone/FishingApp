"""
Configuration for fishing forecast data sources and scoring weights.
Edit AREAS to add new locations. Edit WEIGHTS to tune scoring.
"""

# ── Areas ────────────────────────────────────────────────────────────────────
AREAS = {
    "matagorda": {
        "name": "Matagorda / Sargent, TX",
        "tide_stations": ["8773037", "8772985"],
        "buoy_ids": ["42019", "42035"],
        "nws_office": "HGX",  # NWS Houston/Galveston
        "nws_gridpoint": "HGX/53,51",  # Sargent, TX
        "lat": 28.77,
        "lon": -95.62,
        "marine_zones": ["GMZ330", "GMZ335"],
    },
}

DEFAULT_AREA = "matagorda"

# ── NOAA API endpoints ───────────────────────────────────────────────────────
NOAA_TIDES_API = "https://api.tidesandcurrents.noaa.gov/api/prod/datagetter"
NDBC_OBSERVATION_URL = "https://www.ndbc.noaa.gov/data/realtime2/{station}.txt"
NWS_API_BASE = "https://api.weather.gov"

# ── Scoring weights (must sum to 1.0 per category) ──────────────────────────
INSHORE_WEIGHTS = {
    "tide": 0.30,
    "wind": 0.25,
    "pressure": 0.20,
    "solunar": 0.15,
    "water_temp": 0.05,
    "cloud_cover": 0.05,
}

NEARSHORE_WEIGHTS = {
    "wind": 0.30,
    "swell": 0.25,
    "tide": 0.20,
    "pressure": 0.15,
    "solunar": 0.05,
    "water_temp": 0.05,
}

OFFSHORE_WEIGHTS = {
    "swell": 0.35,
    "wind": 0.30,
    "pressure": 0.15,
    "weather_window": 0.10,
    "solunar": 0.05,
    "water_temp": 0.05,
}

# ── Thresholds ───────────────────────────────────────────────────────────────
WIND_IDEAL_MPH = 10
WIND_FISHABLE_MPH = 15
WIND_OFFSHORE_MAX_MPH = 12
WAVE_OFFSHORE_IDEAL_FT = 2.0
WAVE_OFFSHORE_MAX_FT = 4.0
PRESSURE_STABLE_RANGE_MB = 2.0  # +/- from 1013

# ── Species / season triggers ────────────────────────────────────────────────
SPECIES_TEMP_RANGES = {
    "redfish": {"min": 55, "max": 88, "ideal_min": 65, "ideal_max": 82},
    "trout": {"min": 48, "max": 85, "ideal_min": 55, "ideal_max": 75},
    "flounder": {"min": 50, "max": 82, "ideal_min": 58, "ideal_max": 72},
}

# ── Home Assistant ───────────────────────────────────────────────────────────
HA_URL = "http://homeassistant.local:8123"
HA_TOKEN = ""  # Long-lived access token — set via env var HA_TOKEN

# ── Server ───────────────────────────────────────────────────────────────────
SERVER_HOST = "0.0.0.0"
SERVER_PORT = 5055
